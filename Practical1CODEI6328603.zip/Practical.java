import java.util.*;

/**
 * Some very basic stuff to get you started. It shows basically how each
 * chromosome is built.
 * 
 * @author Jo Stevens
 * @version 1.0, 14 Nov 2008
 * 
 * @author Alard Roebroeck
 * @version 1.1, 12 Dec 2012
 * 
 */

public class Practical {

	static final String TARGET = "HELLO WORLD";
	static ArrayList<Character> alphabet = new ArrayList<>();
	static int FITNESS_CALCULATION_METHOD = 1;
	static int SELECTION_TYPE = 1;
	static double MUTATION_RATE = 0.2;
	static int POP_SIZE = 100;
	static boolean CROSSOVER = true;
	static int MUTATION_TYPE = 1;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// initializing alphabet variable
		// (modified version of the provided code to change alphabet from array to arraylist)
		for (char c = 'A'; c <= 'Z'; c++) {
			alphabet.add(c);
		}
		alphabet.add(' ');
		// Performing Tests
		System.out.println("TEST 1");
		int[] popSizes = {10, 100, 1000, 10000};
		for (int popSize : popSizes) {
			POP_SIZE = popSize;
			System.out.println("POP_SIZE " + POP_SIZE);
			System.out.println("Experiment 1#1");
			FITNESS_CALCULATION_METHOD = 1;
			MUTATION_TYPE = 1;
			SELECTION_TYPE = 1;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
			System.out.println("Experiment 1#2");
			SELECTION_TYPE = 2;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
			System.out.println("Experiment 1#3");
			FITNESS_CALCULATION_METHOD = 2;
			MUTATION_TYPE = 2;
			SELECTION_TYPE = 1;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
			System.out.println("Experiment 1#4");
			SELECTION_TYPE = 2;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
		}
		POP_SIZE = 100;
		System.out.println("TEST 2");
		double[] mutationRates = {0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.99};
		for (double rate : mutationRates) {
			MUTATION_RATE = rate;
			System.out.println("Mutation Rate " + MUTATION_RATE);
			System.out.println("Experiment 2#1");
			FITNESS_CALCULATION_METHOD = 1;
			MUTATION_TYPE = 1;
			SELECTION_TYPE = 1;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
			System.out.println("Experiment 2#2");
			SELECTION_TYPE = 2;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
			System.out.println("Experiment 2#3");
			FITNESS_CALCULATION_METHOD = 2;
			MUTATION_TYPE = 2;
			SELECTION_TYPE = 1;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
			System.out.println("Experiment 2#4");
			SELECTION_TYPE = 2;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
		}
		MUTATION_RATE = 0.2;
		System.out.println("TEST 3");
		boolean[] crossover = {true, false};
		for (boolean b : crossover) {
			CROSSOVER = b;
			System.out.println("CrossOver " + CROSSOVER);
			System.out.println("Experiment 3#1");
			FITNESS_CALCULATION_METHOD = 1;
			MUTATION_TYPE = 1;
			SELECTION_TYPE = 1;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
			System.out.println("Experiment 3#2");
			SELECTION_TYPE = 2;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
			System.out.println("Experiment 3#3");
			FITNESS_CALCULATION_METHOD = 2;
			MUTATION_TYPE = 2;
			SELECTION_TYPE = 1;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
			System.out.println("Experiment 3#4");
			SELECTION_TYPE = 2;
			for (int i = 0; i < 10; i++) {
				System.out.println(performSimulation());
			}
		}
		CROSSOVER = true;
		System.out.println("TEST 4");
		MUTATION_RATE = -1;
		System.out.println("Experiment 4#1");
		FITNESS_CALCULATION_METHOD = 1;
		MUTATION_TYPE = 1;
		SELECTION_TYPE = 1;
		for (int i = 0; i < 10; i++) {
			System.out.println(performSimulation());
		}
		System.out.println("Experiment 4#2");
		SELECTION_TYPE = 2;
		for (int i = 0; i < 10; i++) {
			System.out.println(performSimulation());
		}
		System.out.println("Experiment 4#3");
		FITNESS_CALCULATION_METHOD = 2;
		MUTATION_TYPE = 2;
		SELECTION_TYPE = 1;
		for (int i = 0; i < 10; i++) {
			System.out.println(performSimulation());
		}
		System.out.println("Experiment 4#4");
		SELECTION_TYPE = 2;
		for (int i = 0; i < 10; i++) {
			System.out.println(performSimulation());
		}
	}
	public static int performSimulation() {
		Random generator = new Random(System.currentTimeMillis());
		Individual[] population = new Individual[POP_SIZE];
		// we initialize the population with random characters
		for (int i = 0; i < POP_SIZE; i++) {
			char[] tempChromosome = new char[TARGET.length()];
			for (int j = 0; j < TARGET.length(); j++) {
				tempChromosome[j] = alphabet.get(generator.nextInt(alphabet.size())); //choose a random letter in the alphabet
			}
			population[i] = new Individual(tempChromosome);
		}
		// Starting simulation.
		int generationNo = 1;
		while (generationNo < 10001) {
			// Assigning Fitness Value to all individuals within population.
			for (Individual individual : population) {
				updateFitness(individual);
			}
			// Sorting population based on fitness using the provided HeapSort algorithm.
			HeapSort.sort(population);
			// Checking whether the target has been reached.
			if (population[0].getFitness() == 1.0) break;
			generationNo++;
			// Preparing new population by selecting individuals
			// and creating a set (size POP_SIZE) of new individuals from them.
			population = performSelection(population);
			population = repopulate(population);
			// Mutating the population.
			Mutate(population);
		}
		if (generationNo == 10001) return -1;
		else return generationNo;
	}
	public static void updateFitness(Individual individual) {
		// Calculating Fitness of the individual.
		switch (FITNESS_CALCULATION_METHOD) {
			// Method 1 was prepared to measure the fitness of individuals,
			// while taking into account the characteristics of mutation No 1;
			// It's based on the distance between indexes of 2 characters in the alphabet,
			// while taking into account that " " + 1 -> "A" and "A" - 1 -> " ".
			// To be more exact it's euclidean distance between two Strings that takes into account the above property.
			// "VSYYANJBEYQ" is the String with Fitness that equals exactly 0,
			// as each of its characters is in distance of 13 (alphabet.size() / 2)
			// from the correct one in that position, the furthest possible distance.
			case 1:
				double maxDis = (alphabet.size()/2) * Math.sqrt(TARGET.length());
				char[] characters = individual.getChromosome();
				double distance = 0;
				for (int i = 0; i < characters.length; i++) {
					double x = Math.abs(alphabet.indexOf(characters[i])
							- alphabet.indexOf(TARGET.charAt(i)));
					double value = Math.min(x, alphabet.size() - x);
					value *= value;
					distance += value;
				}
				distance = Math.sqrt(distance);
				individual.setFitness(1 - distance/maxDis);
				break;
			case 2:
				// Distance is calculated as number of incorrect characters
				// on certain positions of the individuals' chromosome.
				double maxDis2 = 11;
				char[] chromosome = individual.getChromosome();
				double dis = 0;
				for (int i = 0; i < chromosome.length; i++) {
					if (chromosome[i] != TARGET.charAt(i)) {
						dis += 1;
					}
				}
				individual.setFitness(1 - dis/maxDis2);
		}
	}
	public static Individual[] performSelection(Individual[] population) {
		switch (SELECTION_TYPE) {
			case 1:
				// Elitist Selection
				// Preserving the best 10% of individuals.
				double percentSelected = 10;
				return Arrays.copyOf(population, ((int) (population.length * percentSelected) / 100));
			case 2:
				// Tournament Selection
				ArrayList<Individual> populationAsList = new ArrayList<>(Arrays.asList(population));
				Collections.shuffle(populationAsList);
				Individual[] newPopulation = new Individual[population.length / 10 + Math.min(1, population.length % 10)];
				for (int i = 0; i < newPopulation.length; i++) {
					Individual[] tournament = new Individual[Math.min(population.length - i * 10, 10)];
					for (int j = 0; j < tournament.length; j++) {
						tournament[j] = populationAsList.get(10 * i + j);
					}
					HeapSort.sort(tournament);
					newPopulation[i] = tournament[0];
				}
				return newPopulation;
		}
		return new Individual[0];
	}
	public static void Mutate(Individual[] population) {
		switch (MUTATION_TYPE) {
			// Mutation type 1:
			// If mutation occurs, then random character in the individual's chromosome is shifted to
			// either a character with index one lower or one higher in the alphabet with a small caveat:
			// if "A" is shifted to character of one lower index, then it's shifted to " ".
			// if " " is shifted to character of one higher index, then it's shifted to "A".
			// Mutation type 2:
			// If mutation occurs, then random character in the individual's chromosome is shifted to
			// a random different character belonging to the alphabet.
			case 1:
				for (Individual individual : population) {
					if (Math.random() < MUTATION_RATE) {
						char[] characters = individual.getChromosome();
						// Index of character to be changed.
						int charInd = (int) (Math.random() * (characters.length));
						boolean increased = ((int) (Math.random() * 2) == 1);
						char newChar;
						if (increased) {
							newChar = alphabet.get((alphabet.indexOf(characters[charInd]) + 1)%(alphabet.size()));
						} else {
							newChar = alphabet.get((alphabet.indexOf(characters[charInd]) - 1 + alphabet.size())%(alphabet.size()));
						}
						characters[charInd] = newChar;
					}
				}
			case 2:
				for (Individual individual : population) {
					if (Math.random() < MUTATION_RATE) {
						char[] characters = individual.getChromosome();
						// Index of character to be changed.
						int charInd = (int) (Math.random() * (characters.length));
						int valueOfNewChar = (int) (Math.random() * (alphabet.size() - 1));
						// Character to be changed is being shifted to a random different character within alphabet.
						if (alphabet.indexOf(characters[charInd]) < valueOfNewChar) {
							characters[charInd] = alphabet.get(valueOfNewChar);
						} else {
							characters[charInd] = alphabet.get(valueOfNewChar + 1);
						}
						individual.setChromosome(characters);
					}
				}
		}
	}
	public static Individual[] repopulate(Individual[] population) {
		Individual[] newPopulation = new Individual[POP_SIZE];
		// Creating new population from newly created individuals;
		// If CROSSOVER == true,
		// then individuals are created from two randomly chosen individuals of previous generation,
		// The chromosome is created by randomly mixing parents' chromosomes;
		// Each gene is equally likely to inherited from either of the parents.
		// If CROSSOVER == false,
		// then individuals are exact copies of one of the individuals from the previous generation.
		// All individuals of the previous generation have roughly equal number of children,
		// if the POP_SIZE doesn't allow for equal distribution,
		// then the individuals of the higher fitness have priority over the ones with lower fitness.
		if (CROSSOVER && population.length > 1) {
			for (int i = 0; i < POP_SIZE; i++) {
				int x = (int) (Math.random() * population.length);
				Individual newInd = population[x].clone();
				char[] newChromosome = newInd.getChromosome();
				int partnerInd = (int) (Math.random() * (population.length - 1));
				if (partnerInd >= x) partnerInd++;
				for (int j = 0; j < newChromosome.length; j++) {
					if ((int) (Math.random() * 2) == 0) {
						newChromosome[j] = population[partnerInd].getChromosome()[j];
					}
				}
				newInd.setChromosome(newChromosome);
				newPopulation[i] = newInd;
			}
		} else {
			int index = 0;
			while (index < POP_SIZE) {
				for (int i = 0; i < population.length && index < POP_SIZE; i++) {
					newPopulation[index++] = population[i].clone();
				}
			}
		}
		return newPopulation;
	}
}
