import java.util.Arrays;

public class Perceptron {
    final static double LEARNING_CONSTANT = 0.1;
    static double[] weights = {Math.random(), Math.random(), Math.random()};
    public static void main(String[] args) {
        System.out.println("Experiment 1");
        int[] input = {1,1};
        int[] input2 = {1,0};
        int[] input3 = {0,1};
        int[] input4 = {0,0};
        double[] previousWeights;
        int nOIterations = 0;
        do {
            System.out.println(Arrays.toString(weights));
            previousWeights = Arrays.copyOf(weights, weights.length);
            adjustWeights(input, 1);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input2, 0);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input3, 0);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input4, 0);
            nOIterations++;
        } while (!Arrays.equals(previousWeights, weights));
        System.out.println("Number of Iterations: " + nOIterations);
        System.out.println(Arrays.toString(weights));
        System.out.println(Arrays.toString(input) + " -> " + compute(input));
        System.out.println(Arrays.toString(input2) + " -> " + compute(input2));
        System.out.println(Arrays.toString(input3) + " -> " + compute(input3));
        System.out.println(Arrays.toString(input4) + " -> " + compute(input4));
        // Exercise 2
        System.out.println("Experiment 2");
        weights = new double[]{Math.random(), Math.random(), Math.random()};
        input = new int[]{1,4};
        input2 = new int[]{1,0};
        input3 = new int[]{0,2};
        input4 = new int[]{0,0};
        nOIterations = 0;
        do {
            System.out.println(Arrays.toString(weights));
            previousWeights = Arrays.copyOf(weights, weights.length);
            adjustWeights(input, 1);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input2, 0);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input3, 1);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input4, 0);
            nOIterations++;
        } while (!Arrays.equals(previousWeights, weights));
        System.out.println("Number of Iterations: " + nOIterations);
        System.out.println(Arrays.toString(weights));
        System.out.println(Arrays.toString(input) + " -> " + compute(input));
        System.out.println(Arrays.toString(input2) + " -> " + compute(input2));
        System.out.println(Arrays.toString(input3) + " -> " + compute(input3));
        System.out.println(Arrays.toString(input4) + " -> " + compute(input4));
        // Exercise 3
        System.out.println("Experiment 3");
        weights = new double[]{Math.random(), Math.random(), Math.random()};
        input = new int[]{1,4};
        input2 = new int[]{1,0};
        input3 = new int[]{0,2};
        input4 = new int[]{0,0};
        int[] input5 = new int[]{2,6};
        int[] input6 = new int[]{2,4};
        int[] input7 = new int[]{3,8};
        int[] input8 = new int[]{3,6};
        nOIterations = 0;
        do {
            System.out.println(Arrays.toString(weights));
            previousWeights = Arrays.copyOf(weights, weights.length);
            adjustWeights(input, 1);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input2, 0);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input3, 1);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input4, 0);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input5, 1);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input6, 0);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input7, 1);
            System.out.println(Arrays.toString(weights));
            adjustWeights(input8, 0);
            nOIterations++;
        } while (!Arrays.equals(previousWeights, weights));
        System.out.println("Number of Iterations: " + nOIterations);
        System.out.println(Arrays.toString(weights));
        System.out.println(Arrays.toString(input) + " -> " + compute(input));
        System.out.println(Arrays.toString(input2) + " -> " + compute(input2));
        System.out.println(Arrays.toString(input3) + " -> " + compute(input3));
        System.out.println(Arrays.toString(input4) + " -> " + compute(input4));
        System.out.println(Arrays.toString(input5) + " -> " + compute(input5));
        System.out.println(Arrays.toString(input6) + " -> " + compute(input6));
        System.out.println(Arrays.toString(input7) + " -> " + compute(input7));
        System.out.println(Arrays.toString(input8) + " -> " + compute(input8));
    }
    public static int compute(int[] input) {
        double sum = 0;
        for (int i = 0; i < input.length; i++) {
            sum += input[i] * weights[i];
        }
        sum += weights[weights.length - 1];
        // step function
        if (sum > 1) return 1;
        else return 0;
    }

    public static void adjustWeights(int[] input, int target) {
        int result = compute(input);
        for (int i = 0; i < input.length; i++) {
            weights[i] += LEARNING_CONSTANT * (target - result) * input[i];
        }
        weights[weights.length - 1] += LEARNING_CONSTANT * (target - result);
    }
}
